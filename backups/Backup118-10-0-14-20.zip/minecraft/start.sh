echo "starting server"
screen -p 0 -dmS minecraft java -Xms2048M -Xmx2048M -jar /home/minecraft/spigot-latest.jar
echo "server started"
