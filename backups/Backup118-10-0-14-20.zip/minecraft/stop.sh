screen -r minecraft -X quit
